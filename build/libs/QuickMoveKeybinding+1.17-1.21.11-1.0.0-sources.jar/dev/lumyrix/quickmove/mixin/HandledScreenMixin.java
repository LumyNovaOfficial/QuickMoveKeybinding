package dev.lumyrix.quickmove.mixin;

import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class HandledScreenMixin {
    @Shadow protected class_1703 handler;

    // -------------------------------------------------------
    // To change the quick move key, edit the two GLFW constants
    // below to any key from https://www.glfw.org/docs/latest/group__keys.html
    // Current key: Left Control (GLFW_KEY_LEFT_CONTROL)
    // Examples:
    //   GLFW.GLFW_KEY_LEFT_ALT   → Left Alt
    //   GLFW.GLFW_KEY_CAPS_LOCK  → Caps Lock
    //   GLFW.GLFW_KEY_R          → R key
    // -------------------------------------------------------
    private static final int QUICK_MOVE_KEY_1 = GLFW.GLFW_KEY_LEFT_CONTROL;
    private static final int QUICK_MOVE_KEY_2 = GLFW.GLFW_KEY_RIGHT_CONTROL;

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), cancellable = true)
    private void quickmove$ctrl(class_1735 slot, int slotId, int button, class_1713 actionType, CallbackInfo ci) {
        if (slot == null) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1761 == null) return;

        long window = client.method_22683().method_4490();
        boolean quickMovePressed = GLFW.glfwGetKey(window, QUICK_MOVE_KEY_1) == GLFW.GLFW_PRESS
                                || GLFW.glfwGetKey(window, QUICK_MOVE_KEY_2) == GLFW.GLFW_PRESS;
        boolean shift = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT)  == GLFW.GLFW_PRESS
                     || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

        if (quickMovePressed && actionType == class_1713.field_7790) {
            client.field_1761.method_2906(handler.field_7763, slotId, button, class_1713.field_7794, client.field_1724);
            ci.cancel();
        } else if (shift && actionType == class_1713.field_7794) {
            client.field_1761.method_2906(handler.field_7763, slotId, button, class_1713.field_7790, client.field_1724);
            ci.cancel();
        }
    }
}
